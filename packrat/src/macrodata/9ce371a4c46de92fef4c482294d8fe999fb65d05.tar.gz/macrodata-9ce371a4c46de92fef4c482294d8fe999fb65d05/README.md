# macrodata

The R package *macrodata* provides functions that enhances Quandl search, downloads cross country data from a specific list of countries and converts xts objects into a panel data. It currently works for almost all series from World Bank and OECD. In other databases the functions may not work as expected since it depends on the pattern of the codes, which may change across datasets.

## Installation

You can install the **development** version from [Github](https://github.com/regisely/macrodata) using the following code in R (>= 3.2.2): 

```r
# install.packages("devtools")
library(devtools)
install_github("regisely/macrodata")
```

## Usage

If you want to see a complete example of usage visit [this post](http://regisely.com/blog/macrodata).

```r
library(macrodata)

## Authenticate Quandl API (sign up at quandl.com to get one)
Quandl.api_key("your_api_key_here")

## Search for macroeconomic data from a specifc country in Quandl
search <- searchQ("gdp per capita start business", country = "Brazil",
                  database = "WWDI")

## Request variables in rows 9 and 11 for all countries in G20
data <- requestQ(search, c(9, 11), countries = "G20")

## Change names of variables
names(data) <- c("gdp", "business")

## Convert the list of xts objects into a panel data
panel <- xtstopanel(data)

## Plot the relations between the two variables for each country
library(car)
scatterplotMatrix(~ gdp + business|country, data = panel,
                   main = "Gdp and Time to start a business by country from G20")

## Run panel data regressions
# install.packages("plm")
library(plm)
reg1 <- plm(gdp ~ business, panel, model = "pooling")
reg2 <- plm(gdp ~ business, panel, model = "within")
reg3 <- plm(gdp ~ business, panel, model = "within", effect = "twoways")
reg4 <- plm(gdp ~ business, panel, model = "random")
reg5 <- plm(gdp ~ business, panel, model = "random", effect = "twoways")

# Make a nice LaTeX table with all regressions
# install.packages("stargazer")
library(stargazer)
stargazer(reg1, reg2, reg3, reg4, reg5)
```

## License

This package is free and open source software, licensed under GPL 3.0.
