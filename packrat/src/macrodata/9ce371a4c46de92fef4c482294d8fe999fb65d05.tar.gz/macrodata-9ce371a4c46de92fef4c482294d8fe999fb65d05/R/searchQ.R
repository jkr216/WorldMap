# Written by Regis A. Ely (regisaely@gmail.com)

# This function improves Quandl.search in three ways:
#  1) It allows for more than 100 results;
#  2) It allows filter by specific countries or part of the name of a
#  series;
#  3) It allows filter by specific frequencies.

searchQ <- function(pattern = "", country = "", database = "",
                    frequency = "", n = 300, view = TRUE) {

  # Check if frequencies are correct.
  frequencies <- c("", "annual", "quarterly", "monthly", "daily")
  if (!all(frequency %in% frequencies)) {
    stop(paste0(c("Invalid frequency for data:",
                  frequency[which(!(frequency %in% frequencies))]),
                collapse = " "), ".")
  }

  # Check if only one country is informed.
  if (length(country) > 1) {
    stop("You should search for only one specific country and then request data for many countries with the requestQ function.")
  }

  # Search for pattern and country.
  pattern <- paste(pattern, country)
  Qsearch <- Quandl.search(pattern, database_code = database,
                           per_page = n, page = 1, silent = TRUE)

  # Initialize loop for more than 100 results.
  aux <- n - 100
  i <- 1
  while (aux > 0) {
    i <- i + 1
    Qsearch <- rbind(Qsearch,
                     Quandl.search(pattern, database_code = database,
                                   per_page = aux, page = i,
                                   silent = TRUE))
    aux <- aux - 100
  }

  # Filter results by country and frequency.
  Qsearch <- Qsearch[grep(country, Qsearch$name, fixed = TRUE), ]
  Qsearch <- Qsearch[grep(paste(frequency, collapse = "|"),
                          Qsearch$frequency, fixed = FALSE), ]

  # Add column with row numbers.
  Qsearch$row <- 1:nrow(Qsearch)
  col <- ncol(Qsearch)
  Qsearch <- Qsearch[, c(col, 1:(col-1))]

  # Save country and frequency as attributes.
  attributes(Qsearch)$country <- country
  attributes(Qsearch)$frequency <- frequency

  # View results.
  if (view == TRUE) {
    View(Qsearch)
  }
  return(Qsearch)
}
